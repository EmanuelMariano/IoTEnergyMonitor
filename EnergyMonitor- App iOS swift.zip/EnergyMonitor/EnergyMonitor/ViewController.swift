//
//  ViewController.swift
//  EnergyMonitor
//
//  Created by Ricardo Torquato Tavares on 05/06/16.
//  Copyright © 2016 com.energy.monitor. All rights reserved.
//

import UIKit
import Charts
import CoreMotion

class ViewController: UIViewController, ChartViewDelegate {
    
    @IBOutlet weak var chartView: BarChartView!
    var days:[String] = []
    var stepsTaken:[Int] = []
    let activityManager = CMMotionActivityManager()
    let pedoMeter = CMPedometer()
    
    var cnt = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        chartView.delegate = self;
        
        chartView.descriptionText = "";
        chartView.noDataTextDescription = "Data will be loaded soon."
        
        chartView.drawBarShadowEnabled = false
        chartView.drawValueAboveBarEnabled = true
        
        chartView.maxVisibleValueCount = 60
        chartView.pinchZoomEnabled = false
        chartView.drawGridBackgroundEnabled = true
        chartView.drawBordersEnabled = false
        
        getDataForLastWeek()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func dismiss(sender: AnyObject) {
        self.dismissViewControllerAnimated(true, completion: nil)
    }
    
    func getDataForLastWeek() {
        if(CMPedometer.isStepCountingAvailable()){
            var serialQueue : dispatch_queue_t  = dispatch_queue_create("com.example.MyQueue", nil)
            
            let formatter = NSDateFormatter()
            formatter.dateFormat = "d MMM"
            dispatch_sync(serialQueue, { () -> Void in
                let today = NSDate()
                for day in 0...6{
                    let fromDate = NSDate(timeIntervalSinceNow: Double(-7+day) * 86400)
                    let toDate = NSDate(timeIntervalSinceNow: Double(-7+day+1) * 86400)
                    let dtStr = formatter.stringFromDate(toDate)
                    self.pedoMeter.queryPedometerDataFromDate(fromDate, toDate: toDate) { (data : CMPedometerData!, error) -> Void in
                        if(error == nil){
                            println("\(dtStr) : \(data.numberOfSteps)")
                            self.days.append(dtStr)
                            self.stepsTaken.append(Int(data.numberOfSteps))
                            println("Days :\(self.days)")
                            println("Steps :\(self.stepsTaken)")
                            if(self.days.count == 7){
                                dispatch_sync(dispatch_get_main_queue(), { () -> Void in
                                    let xVals = self.days
                                    var yVals: [BarChartDataEntry] = []
                                    for idx in 0...6 {
                                        yVals.append(BarChartDataEntry(value: Float(self.stepsTaken[idx]), xIndex: idx))
                                    }
                                    println("Days :\(self.days)")
                                    println("Steps :\(self.stepsTaken)")
                                    
                                    let set1 = BarChartDataSet(yVals: yVals, label: "Steps Taken")
                                    set1.barSpace = 0.25
                                    
                                    let data = BarChartData(xVals: xVals, dataSet: set1)
                                    data.setValueFont(UIFont(name: "Avenir", size: 12))
                                    self.chartView.data = data
                                    self.view.reloadInputViews()
                                })
                                
                            }
                        }
                    }
                    
                }
                
            })
        }
    }
    
}
}

